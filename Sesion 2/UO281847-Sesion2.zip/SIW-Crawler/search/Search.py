class Search:
    def crawl(self, links: list[str]):
        pass
